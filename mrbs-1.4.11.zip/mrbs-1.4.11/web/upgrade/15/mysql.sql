# $Id: mysql.sql 1541 2010-10-23 13:10:24Z cimorrison $
