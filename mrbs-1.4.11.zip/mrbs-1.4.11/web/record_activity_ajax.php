<?php
// $Id: record_activity_ajax.php 2784 2013-11-21 10:48:22Z cimorrison $

// An Ajax function to record user activity on the client side.   (If there is some activity then
// this will be picked up and used by the appropriate session file).

require "defaultincludes.inc";
